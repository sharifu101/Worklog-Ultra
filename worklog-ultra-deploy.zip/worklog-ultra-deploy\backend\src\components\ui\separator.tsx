export function Separator() {
  return <div className="h-px w-full bg-[var(--panel-border)]" />;
}
